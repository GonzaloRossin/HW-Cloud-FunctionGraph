# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateAutopilotReleaseRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'name': 'str',
        'namespace': 'str',
        'cluster_id': 'str',
        'body': 'UpdateReleaseReqBody'
    }

    attribute_map = {
        'name': 'name',
        'namespace': 'namespace',
        'cluster_id': 'cluster_id',
        'body': 'body'
    }

    def __init__(self, name=None, namespace=None, cluster_id=None, body=None):
        """UpdateAutopilotReleaseRequest

        The model defined in huaweicloud sdk

        :param name: 模板实例名称
        :type name: str
        :param namespace: 模板实例所在的命名空间
        :type namespace: str
        :param cluster_id: 集群ID，获取方式请参见[如何获取接口URI中参数](cce_02_0271.xml)。
        :type cluster_id: str
        :param body: Body of the UpdateAutopilotReleaseRequest
        :type body: :class:`huaweicloudsdkcce.v3.UpdateReleaseReqBody`
        """
        
        

        self._name = None
        self._namespace = None
        self._cluster_id = None
        self._body = None
        self.discriminator = None

        self.name = name
        self.namespace = namespace
        self.cluster_id = cluster_id
        if body is not None:
            self.body = body

    @property
    def name(self):
        """Gets the name of this UpdateAutopilotReleaseRequest.

        模板实例名称

        :return: The name of this UpdateAutopilotReleaseRequest.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this UpdateAutopilotReleaseRequest.

        模板实例名称

        :param name: The name of this UpdateAutopilotReleaseRequest.
        :type name: str
        """
        self._name = name

    @property
    def namespace(self):
        """Gets the namespace of this UpdateAutopilotReleaseRequest.

        模板实例所在的命名空间

        :return: The namespace of this UpdateAutopilotReleaseRequest.
        :rtype: str
        """
        return self._namespace

    @namespace.setter
    def namespace(self, namespace):
        """Sets the namespace of this UpdateAutopilotReleaseRequest.

        模板实例所在的命名空间

        :param namespace: The namespace of this UpdateAutopilotReleaseRequest.
        :type namespace: str
        """
        self._namespace = namespace

    @property
    def cluster_id(self):
        """Gets the cluster_id of this UpdateAutopilotReleaseRequest.

        集群ID，获取方式请参见[如何获取接口URI中参数](cce_02_0271.xml)。

        :return: The cluster_id of this UpdateAutopilotReleaseRequest.
        :rtype: str
        """
        return self._cluster_id

    @cluster_id.setter
    def cluster_id(self, cluster_id):
        """Sets the cluster_id of this UpdateAutopilotReleaseRequest.

        集群ID，获取方式请参见[如何获取接口URI中参数](cce_02_0271.xml)。

        :param cluster_id: The cluster_id of this UpdateAutopilotReleaseRequest.
        :type cluster_id: str
        """
        self._cluster_id = cluster_id

    @property
    def body(self):
        """Gets the body of this UpdateAutopilotReleaseRequest.

        :return: The body of this UpdateAutopilotReleaseRequest.
        :rtype: :class:`huaweicloudsdkcce.v3.UpdateReleaseReqBody`
        """
        return self._body

    @body.setter
    def body(self, body):
        """Sets the body of this UpdateAutopilotReleaseRequest.

        :param body: The body of this UpdateAutopilotReleaseRequest.
        :type body: :class:`huaweicloudsdkcce.v3.UpdateReleaseReqBody`
        """
        self._body = body

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateAutopilotReleaseRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
